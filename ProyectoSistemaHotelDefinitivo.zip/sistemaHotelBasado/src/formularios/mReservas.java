package formularios;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import sql.dbConnection;

public class mReservas extends javax.swing.JFrame {

    Connection cn;
    Statement st;
    ResultSet rs;
    DefaultTableModel modelo;
    String ID;
    private Connection conn = null;// Inicializamos con 1

    public mReservas() {
        initComponents();
        setLocationRelativeTo(null);
        conn = dbConnection.connect();

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(mUsuariosModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(mUsuariosModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(mUsuariosModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(mUsuariosModificar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new mReservas().setVisible(true);
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btn_back = new javax.swing.JButton();
        btn_registrar1 = new javax.swing.JButton();
        Ingreso1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtHabitacion = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtMonto = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtCliente = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtReserva = new javax.swing.JTextField();
        btn_moduloHabitacion1 = new javax.swing.JButton();
        btn_moduloCliente = new javax.swing.JButton();
        btn_buscarCliente = new javax.swing.JButton();
        btn_moduloPaago = new javax.swing.JButton();
        btn_buscarPago = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        dateReserva = new com.toedter.calendar.JDateChooser();
        dateIngreso = new com.toedter.calendar.JDateChooser();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        BtnEliminar = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        BtnNuevo = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        BtnModificar = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        BtnAgregar = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn_back.setIcon(new javax.swing.ImageIcon(getClass().getResource("/formularios/devolver.png"))); // NOI18N
        btn_back.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        btn_back.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_back.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_backActionPerformed(evt);
            }
        });
        jPanel1.add(btn_back, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, 30, 30));

        btn_registrar1.setBackground(new java.awt.Color(255, 204, 0));
        btn_registrar1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 3, true));
        btn_registrar1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btn_registrar1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btn_registrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_registrar1ActionPerformed(evt);
            }
        });
        jPanel1.add(btn_registrar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 20, 30));

        Ingreso1.setBackground(new java.awt.Color(255, 255, 255));
        Ingreso1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("ID HABITACIÓN:");
        Ingreso1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 43, 95, -1));

        txtHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtHabitacionActionPerformed(evt);
            }
        });
        Ingreso1.add(txtHabitacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 40, 71, -1));

        jLabel2.setText("ID CLIENTE");
        Ingreso1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 77, 95, -1));

        txtMonto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMontoActionPerformed(evt);
            }
        });
        Ingreso1.add(txtMonto, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 115, 75, -1));

        jLabel4.setText("ID PAGO:");
        Ingreso1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 118, 95, -1));

        txtCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtClienteActionPerformed(evt);
            }
        });
        Ingreso1.add(txtCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 74, 85, -1));

        jLabel7.setText("ID RESERVA:");
        Ingreso1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 9, 95, -1));

        txtReserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtReservaActionPerformed(evt);
            }
        });
        Ingreso1.add(txtReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(125, 6, 71, -1));

        btn_moduloHabitacion1.setText("+");
        btn_moduloHabitacion1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_moduloHabitacion1ActionPerformed(evt);
            }
        });
        Ingreso1.add(btn_moduloHabitacion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(208, 42, -1, 20));

        btn_moduloCliente.setText("+");
        btn_moduloCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_moduloClienteActionPerformed(evt);
            }
        });
        Ingreso1.add(btn_moduloCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(216, 74, -1, -1));

        btn_buscarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/formularios/lupa.png"))); // NOI18N
        btn_buscarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarClienteActionPerformed(evt);
            }
        });
        Ingreso1.add(btn_buscarCliente, new org.netbeans.lib.awtextra.AbsoluteConstraints(245, 74, -1, -1));

        btn_moduloPaago.setText("+");
        btn_moduloPaago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_moduloPaagoActionPerformed(evt);
            }
        });
        Ingreso1.add(btn_moduloPaago, new org.netbeans.lib.awtextra.AbsoluteConstraints(212, 116, 24, 22));

        btn_buscarPago.setIcon(new javax.swing.ImageIcon(getClass().getResource("/formularios/lupa.png"))); // NOI18N
        btn_buscarPago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_buscarPagoActionPerformed(evt);
            }
        });
        Ingreso1.add(btn_buscarPago, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 120, 24, 22));

        jPanel1.add(Ingreso1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, 360, -1));

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setText("Fecha de Reserva:");
        jPanel4.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 100, -1));

        jLabel6.setText("Fecha de Ingreso:");
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 100, -1));

        dateReserva.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        dateReserva.setDateFormatString("y/MM/dd");
        jPanel4.add(dateReserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 119, -1));

        dateIngreso.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        dateIngreso.setDateFormatString("y/MM/dd");
        jPanel4.add(dateIngreso, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 60, 119, -1));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 290, 270, 100));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 130, 190, 150));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setText("GESTIÓN DE RESERVAS");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, -1, -1));

        jSeparator1.setBackground(new java.awt.Color(255, 255, 255));
        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));
        jSeparator1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 810, 420));

        BtnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/borrar.png"))); // NOI18N
        BtnEliminar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        BtnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(BtnEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 400, 40, 30));

        jButton2.setBackground(new java.awt.Color(255, 204, 51));
        jButton2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 400, 20, 30));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/lupa.png"))); // NOI18N
        jButton1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 400, 40, 30));

        jButton6.setBackground(new java.awt.Color(255, 204, 51));
        jButton6.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 400, 20, 30));

        BtnNuevo.setText("NUEVO");
        BtnNuevo.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        BtnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnNuevoActionPerformed(evt);
            }
        });
        jPanel1.add(BtnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 400, 90, 30));

        jButton5.setBackground(new java.awt.Color(255, 204, 51));
        jButton5.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel1.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 400, 20, 30));

        BtnModificar.setText("MODIFICAR");
        BtnModificar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        BtnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnModificarActionPerformed(evt);
            }
        });
        jPanel1.add(BtnModificar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 400, 90, 30));

        jButton4.setBackground(new java.awt.Color(255, 204, 51));
        jButton4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 400, 20, 30));

        BtnAgregar.setText("AGREGAR");
        BtnAgregar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        BtnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnAgregarActionPerformed(evt);
            }
        });
        jPanel1.add(BtnAgregar, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, 90, 30));

        jButton3.setBackground(new java.awt.Color(255, 204, 51));
        jButton3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 400, 20, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 940, 530));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtHabitacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtHabitacionActionPerformed

    private void txtMontoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMontoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMontoActionPerformed

    private void BtnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnAgregarActionPerformed
        Agregar();

    }//GEN-LAST:event_BtnAgregarActionPerformed

    private void BtnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnEliminarActionPerformed
        Eliminar();    // TODO add your handling code here:
    }//GEN-LAST:event_BtnEliminarActionPerformed

    private void txtClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtClienteActionPerformed

    private void BtnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnNuevoActionPerformed
        Nuevo();    // TODO add your handling code here:
    }//GEN-LAST:event_BtnNuevoActionPerformed

    private void BtnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnModificarActionPerformed
        Modificar();
    }//GEN-LAST:event_BtnModificarActionPerformed

    private void txtReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtReservaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtReservaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        abrirBusqueda();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btn_moduloHabitacion1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_moduloHabitacion1ActionPerformed
        try {
            obtenerIDhabitaciones();
        } catch (SQLException ex) {
            Logger.getLogger(mReservas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btn_moduloHabitacion1ActionPerformed

    private void btn_moduloClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_moduloClienteActionPerformed
        abrirClientes();
    }//GEN-LAST:event_btn_moduloClienteActionPerformed

    private void btn_buscarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarClienteActionPerformed
        try {
            obtenerIDCliente();
        } catch (SQLException ex) {
            Logger.getLogger(mReservas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btn_buscarClienteActionPerformed

    private void btn_buscarPagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_buscarPagoActionPerformed
        try {
            obtenerIDPagos();
        } catch (SQLException ex) {
            Logger.getLogger(mReservas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btn_buscarPagoActionPerformed

    private void btn_moduloPaagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_moduloPaagoActionPerformed
        abrirDialogoPagos();
    }//GEN-LAST:event_btn_moduloPaagoActionPerformed

    private void btn_backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_backActionPerformed
        retornarModulo();
    }//GEN-LAST:event_btn_backActionPerformed

    private void btn_registrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_registrar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_registrar1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    void Modificar() {
        String IDHabitación = txtHabitacion.getText();
        String IDCliente = txtCliente.getText();
        String sql = "update Reservaciones set cliente_id='" + IDCliente + "',habitacion_id='" + IDHabitación + "' where reservacion_id=+id";
        if (IDHabitación.equals("") || IDCliente.equals("")) {
            JOptionPane.showMessageDialog(null, "Rellene las casillas por favor");
        } else {
            try {
                cn = dbConnection.connect();
                st = cn.createStatement();
                st.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, "Usuario Desactualizado");
            } catch (Exception e) {
            }
        }
    }



    private void Agregar() {
        String IDhab = txtHabitacion.getText();
        String IDcli = txtCliente.getText();
        String mont = txtMonto.getText();
        String fecha_reserva = ((JTextField) dateReserva.getDateEditor().getUiComponent()).getText();
        String fecha_ingreso = ((JTextField) dateIngreso.getDateEditor().getUiComponent()).getText();
        if (IDhab.equals("") || IDcli.equals("") || mont.equals("") || fecha_reserva.equals("") || fecha_ingreso.equals("")) {
            JOptionPane.showMessageDialog(null, "Por favor, Introduzca los ID correspondientes ");
        } else {
            String sql = "insert into Reservaciones(cliente_id, habitacion_id, fecha_entrada, fecha_salida, monto) values ('" + IDcli + "','" + IDhab + "','" + fecha_reserva + "','" + fecha_ingreso + "','" + mont + "')";
            System.out.println(sql);
            Connection cn = null;
            Statement st = null;
            try {
                cn = dbConnection.connect();
                st = cn.createStatement();
                cn.setAutoCommit(false);  // Deshabilitar el auto-commit
                st.executeUpdate(sql);
                cn.commit();  // Hacer commit de la transacción

                // Agregar los datos a la tabla en la interfaz de usuario
                // Incrementar nextReservaId y actualizar txtReserva
                txtReserva.setText(String.valueOf(idSiguiente()));
                JOptionPane.showMessageDialog(rootPane, "Registrado con exito! \nID: " + String.valueOf(idSiguiente()));
            } catch (SQLException e) {
                if (cn != null) {
                    try {
                        cn.rollback();  // Hacer rollback de la transacción en caso de error
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, "Error al hacer rollback: " + ex.getMessage());
                    }
                }
                JOptionPane.showMessageDialog(null, "Error al insertar los datos: " + e.getMessage());
            }
        }
        System.out.println("Antes de Nuevo()");
        Nuevo();
        System.out.println("Después de Nuevo() y antes de limpieza()");
        System.out.println("Después de limpieza() y antes de listar()");
        System.out.println("Después de listar()");
        System.out.println("SI");
    }

    

    void Eliminar() {
        String id = JOptionPane.showInputDialog("Ingrese ID a eliminar").toString();
        this.eliminarID(id);
        //this.tbl_usuarios.removeAll();
    }

    void Nuevo() {
        txtReserva.setText("");
        txtHabitacion.setText("");
        txtCliente.setText("");
        txtMonto.setText("");
        dateReserva.setDate(null);
        dateIngreso.setDate(null);
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnAgregar;
    private javax.swing.JButton BtnEliminar;
    private javax.swing.JButton BtnModificar;
    private javax.swing.JButton BtnNuevo;
    private javax.swing.JPanel Ingreso1;
    private javax.swing.JButton btn_back;
    private javax.swing.JButton btn_buscarCliente;
    private javax.swing.JButton btn_buscarPago;
    private javax.swing.JButton btn_moduloCliente;
    private javax.swing.JButton btn_moduloHabitacion1;
    private javax.swing.JButton btn_moduloPaago;
    private javax.swing.JButton btn_registrar1;
    private com.toedter.calendar.JDateChooser dateIngreso;
    private com.toedter.calendar.JDateChooser dateReserva;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField txtCliente;
    private javax.swing.JTextField txtHabitacion;
    private javax.swing.JTextField txtMonto;
    private javax.swing.JTextField txtReserva;
    // End of variables declaration//GEN-END:variables

    private int idSiguiente() {
        String sql = "SELECT MAX(reservacion_id) AS max_id FROM Reservaciones";
        int nextReservaId = 0;
        try {
            cn = dbConnection.connect();
            st = cn.createStatement();
            rs = st.executeQuery(sql);
            if (rs.next()) {
                nextReservaId = rs.getInt("max_id");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener el ID máximo: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (st != null) {
                    st.close();
                }
                if (cn != null) {
                    cn.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error al cerrar la conexión: " + e.getMessage());
            }
        }
        System.out.println(nextReservaId);
        return nextReservaId;

    }

    private void obtenerIDhabitaciones() throws SQLException {
        mBusqueda modulo = new mBusqueda(conn, "Habitaciones");
        modulo.setVisible(true);
        modulo.modoSeleccion();
    }

    private void obtenerIDCliente() throws SQLException {
        mBusqueda modulo = new mBusqueda(conn, "Clientes");
        modulo.setVisible(true);
        modulo.modoSeleccion();
    }

    public void cambiarID(String id) {
        this.txtHabitacion.setText(id);
    }

    private void obtenerIDPagos() throws SQLException {
        mBusqueda modulo = new mBusqueda(conn, "Pagos");
        modulo.setVisible(true);
        modulo.modoSeleccion();
    }

    private void abrirClientes() {
        mClientes modulo = new mClientes();
        modulo.modoDialogo = true;
        modulo.setVisible(true);
    }

    private void abrirDialogoPagos() {
        rPagos modulo = new rPagos();
        modulo.modoDialogo = true;
        modulo.setVisible(true);
    }

    private void portapapeles(String value) {
        StringSelection stringSelection = new StringSelection(value);

        // Obtener el portapapeles del sistema
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        // Copiar el texto al portapapeles
        clipboard.setContents(stringSelection, null);
    }

    private void retornarModulo() {
        this.dispose();
    }

    private void eliminarID(String id) {
        PreparedStatement psmt = null;
        try {
            String sql = "DELETE FROM Reservaciones WHERE reservacion_id = ?";
            psmt = conn.prepareStatement(sql);
            psmt.setString(1, id);
            psmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void abrirBusqueda() {
        try {
            mBusqueda modulo = new mBusqueda(conn,"Reservaciones");
            modulo.modoSeleccion();
            modulo.setVisible(true);
            
        } catch (SQLException ex) {
            Logger.getLogger(mReservas.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
